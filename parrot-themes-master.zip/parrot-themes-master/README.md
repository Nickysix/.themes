# parrot-themes

![Alt text](screenshots/screenshots1.png?raw=true "Application categories")
![Alt text](screenshots/screenshots2.png?raw=true "New gtk icons")
![Alt text](screenshots/screenshots3.png?raw=true "New gtk icons")
