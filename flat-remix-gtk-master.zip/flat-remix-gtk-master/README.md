![Flat Remix GTK theme](https://github.com/daniruiz/flat-remix-gtk/raw/master/assets/logo.png)
===============================

# More information at [drasite.com/flat-remix-gtk](https://drasite.com/flat-remix-gtk)

![theme preview](https://github.com/daniruiz/flat-remix-gtk/raw/master/assets/preview.png)
